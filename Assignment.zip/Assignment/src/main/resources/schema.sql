CREATE TABLE YB_ORDERS
(
	ID NUMBER(19) NOT NULL,
	client_order_id NUMBER(19) NOT NULL,
    side	VARCHAR2(5),
    price	NUMBER(32,8),
    volume	NUMBER(19),
    received_time	TIMESTAMP
);
