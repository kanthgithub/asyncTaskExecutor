package com.yieldBroker.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;

public class YBOrderModel {

    private Integer clientOrderId;

    private String side;

    private BigDecimal price;

    private Integer volume;

    @JsonIgnore
    private Date receivedTime;

    public Integer getClientOrderId() {
        return clientOrderId;
    }

    public YBOrderModel setClientOrderId(Integer clientOrderId) {
        this.clientOrderId = clientOrderId;
        return this;
    }

    public String getSide() {
        return side;
    }

    public YBOrderModel setSide(String side) {
        this.side = side;
        return this;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public YBOrderModel setPrice(BigDecimal price) {
        this.price = price;
        return this;
    }

    public Integer getVolume() {
        return volume;
    }

    public YBOrderModel setVolume(Integer volume) {
        this.volume = volume;
        return this;
    }

    public Date getReceivedTime() {
        return receivedTime;
    }

    public YBOrderModel setReceivedTime(Date receivedTime) {
        this.receivedTime = receivedTime;
        return this;
    }
}
