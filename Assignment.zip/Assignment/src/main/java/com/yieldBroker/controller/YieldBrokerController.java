package com.yieldBroker.controller;

import com.yieldBroker.model.YBOrderModel;
import com.yieldBroker.service.YBOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

@RestController
@RequestMapping("/yieldBroker")
public class YieldBrokerController {

	@Autowired
	private YBOrderService ybOrderService;
	
	@RequestMapping(path="/orderBook", method = RequestMethod.GET)
	public Iterable<YBOrderModel> getOrderBook() throws IOException {
		return ybOrderService.getOrderBook();
	}
	
	@RequestMapping(value = "/order", method = RequestMethod.POST)
	@ResponseBody
	public YBOrderModel saveByRepo(@RequestBody YBOrderModel ybOrderModel) {

		return ybOrderService.storeOrder(ybOrderModel);
	}
}
