package com.yieldBroker.repository;

import com.yieldBroker.entity.YBOrders;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OrderRepository extends JpaRepository<YBOrders, Long> , OrderCustomRepository {

    public List<YBOrders> findAllByOrderBySideAscReceivedTimeDesc();

}