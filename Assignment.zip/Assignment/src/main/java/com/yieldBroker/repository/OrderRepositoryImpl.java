package com.yieldBroker.repository;

import com.yieldBroker.entity.YBOrders;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class OrderRepositoryImpl implements OrderCustomRepository {

    @Override
    public List<YBOrders> getOrderBook() {
        return null;
    }
}
