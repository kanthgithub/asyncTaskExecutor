package com.yieldBroker.repository;

import com.yieldBroker.entity.YBOrders;

import java.util.List;

public interface OrderCustomRepository {

    public List<YBOrders> getOrderBook();
}
