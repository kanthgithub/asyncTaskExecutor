package com.yieldBroker.service;

import com.yieldBroker.entity.YBOrders;
import com.yieldBroker.model.YBOrderModel;
import com.yieldBroker.repository.OrderRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.expression.ParseException;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class YBOrderServiceImpl implements YBOrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<YBOrderModel> getOrderBook() {
        List<YBOrders> ybOrdersCollection = orderRepository.findAllByOrderBySideAscReceivedTimeDesc();

        List<YBOrderModel> buyOrders =
                getBuyOrdersForOrderBook(ybOrdersCollection).parallelStream()
                                                            .map(ybOrders -> convertToModel(ybOrders))
                                                                .collect(Collectors.toList());

        List<YBOrderModel> sellOrders =
                getSellOrdersForOrderBook(ybOrdersCollection).parallelStream()
                                            .map(ybOrders -> convertToModel(ybOrders))
                                                        .collect(Collectors.toList());

        return Stream.concat(buyOrders.stream(), sellOrders.stream()).collect(Collectors.toList());
    }

    public List<YBOrders> getBuyOrdersForOrderBook(List<YBOrders> ybOrdersList) {
        return ybOrdersList.parallelStream()
                .filter(ybOrders -> ybOrders.getSide().equalsIgnoreCase("Buy"))
                .sorted(Comparator.comparing(YBOrders::getPrice).reversed().thenComparing(YBOrders::getReceivedTime))
                .collect(Collectors.toList());
    }

    public List<YBOrders> getSellOrdersForOrderBook(List<YBOrders> ybOrdersList) {
        return ybOrdersList.parallelStream()
                .filter(ybOrders -> ybOrders.getSide().equalsIgnoreCase("Sell"))
                .sorted(Comparator.comparing(YBOrders::getPrice).thenComparing(YBOrders::getReceivedTime))
                .collect(Collectors.toList());
    }

    @Override
    public YBOrderModel storeOrder(YBOrderModel ybOrderModel) {
        YBOrders ybOrders = convertToEntity(ybOrderModel);
        YBOrders ybOrderSaved = orderRepository.save(ybOrders);
        return convertToModel(ybOrderSaved);
    }

    private YBOrders convertToEntity(YBOrderModel ybOrderModel) throws ParseException {
        return modelMapper.map(ybOrderModel, YBOrders.class);
    }

    private YBOrderModel convertToModel(YBOrders ybOrders) throws ParseException {
        return modelMapper.map(ybOrders, YBOrderModel.class);
    }
}
