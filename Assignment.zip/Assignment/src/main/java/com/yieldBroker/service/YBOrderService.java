package com.yieldBroker.service;

import com.yieldBroker.model.YBOrderModel;

import java.util.List;

public interface YBOrderService {

    public List<YBOrderModel> getOrderBook();

    public YBOrderModel storeOrder(YBOrderModel ybOrderModel);

}
