## Multi-Storey Parking Lot - Management:

 - multi-storey parking lot that can hold up to 'n' cars at any given point in time.

 - Each slot is given a number starting at 1 increasing with increasing distance from the entry point in steps of one.

 - This is an automated ticketing system that allows my customers to use my parking lot without human intervention.


## Tech-Stack:

- Algorithm is implemented in jdk-8 and runs on jre-8

- Junit & Cucumber used for unit-testing

- Maven project

## Features:

1. Create a new canvas
2. Start drawing on the canvas by issuing various commands
3. Quit

At the moment, the program should support the following commands:

C w h           Should create a new canvas of width w and height h.

L xCoordinate1 yCoordinate1 xCoordinate2 yCoordinate2   Should create a new line from (xCoordinate1,yCoordinate1) to (xCoordinate2,yCoordinate2).
                Currently only horizontal or vertical lines are supported. 
                Horizontal and vertical lines will be drawn using the 'xCoordinate' character.
                
R xCoordinate1 yCoordinate1 xCoordinate2 yCoordinate2   Should create a new rectangle, whose upper left corner is (xCoordinate1,yCoordinate1) and lower right corner is (xCoordinate2,yCoordinate2).
                Horizontal and vertical lines will be drawn using the 'xCoordinate' character.
B xCoordinate yCoordinate c Q       Should fill the entire area connected to (xCoordinate,yCoordinate) with "colour" c.

                The behaviour of this is the same as that of the "bucket fill" tool in paint programs.

Q               Should quit the program.

## Design:

### Package Structure:

- ```com.parkinglot.model``` (Model classes)
- ```com.parkinglot.repository``` (Data Store)
- ```com.parkinglot.service``` (APIGateway , Command/Query Services)
- ```com.parkinglot.util```  (utility classes - file parser)
- ```Main.java``` (Main program - entry point)
- ```com.parkinglot.ParkingLotCommandExecutor.java``` executes the parsed command


### DataModel:

 - Storage: ParkingLot data is stored in a map

   - ConcurrentHashMap with Integer as Key and Car Object as Value
   - key represents the Slot occupied by car
   - Value represents the Parked Car

 - Car: Parking Lot is to park Cars.

   - registrationNumber
   - color

###  Services:

 - Services are implemented similar to Command Query Seggregation (CQRS)

 - API-Gateway: entry point for clients to consume parkinglot services

   ```com.parkinglot.service.ParkingLotAPIGatewayService```

 - Command Service responsibilites :

    ```com.parkinglot.service.ParkingLotCommandService```

    - Create a new Parking Lot
    - Park a Car
    - Leave a Car from the Parking-Lot

  - Query Service responsibilities :

    ```com.parkinglot.service.ParkingLotQueryService```

    - Generate Status Report of parking
    - Extract Registration Numbers of all parked cars with a specific color
    - Extract Slot numbers occupied by all parked cars with a specific color
    - Extract slot Number of a Parked car using registration Number

   - Print response-Model Objects as String to console:

      ```com.parkinglot.service.ParkingLotOperationsService```

     - Command and Query Services return responseModel objects
     - Response is converted in to user-readable format as mentioned in requirement document
     - Responsibility of this class is to consume services via API-Gateway and print the response on out console

### Utilities:

    - Parse command Strings
    - Identify method to be invoked
    - Execute the commands via ParkingLotOperationService
    - Java Reflections library used to convert command to methods


## Test Scenarios:

 All tests are under project root folder and directory path: src/test/java/

 Command Service/Operations Tests:

  ```com.parkinglot.service.ParkingLotOperationsServiceTest```
  ```com.parkinglot.service.ParkingLotCommandServiceTest```


- Create a new Parking Lot

- Park a Car

- Leave a Car from the Parking Lot


 Query Service/Operations Tests:

  ```com.parkinglot.service.ParkingLotOperationsServiceTest```
  ```com.parkinglot.service.ParkingLotQueryServiceTest```


- Generate Status Report of parking

- Extract Registration Numbers of all parked cars with a specific color

- Extract Slot numbers occupied by all parked cars with a specific color

- Extract slot Number of a Parked car using registration Number

## Pre-Requisites To Build & Run:

- Make sure to install jdk-8 and maven 3

- Extract archive file contents to folder ParkingLotOperations

- navigate to project Home Directory ParkingLotOperations

- verify versions by executing command:
    ```sh
    java -version
    ```

     ```sh
     mvn -version
     ```

- This will print java and maven versions



## How to run:

 - Navigate to Project Root-folder

 - Application root folder has a script file ``` parking_lot.sh ```

 - open script ``` parking_lot.sh ``` with vi or vim or enter in vi command mode (key Esc)
     - Then type this:

     ```sh
      :set fileformat=unix
     ```

     Finally save it
     ```sh
        :wq!
     ```

 - to build and run the application in interactive mode, please run command:

     ```sh
        ./parking_lot.sh
      ```

    This will clean,build,install the package and open an interactive console

  - to build and run the application for a specific test-file, please run command:

      ```sh
         ./parking_lot.sh file_inputs.txt
       ```

       -  This will clean,build,install the package and run the commands in the file

       -  Filename specified is for explanation, you can set any name but it should be a valid text file


### Issues while running:

 - frequent issues while running application would be shell script fails to execute

    - To fix, open your script with vi or vim and enter in vi command mode (key Esc)
    - Then type this:

    ```sh
     :set fileformat=unix
    ```

    Finally save it
    ```sh
       :wq!
    ```

## How to use interactive console:

  - You are expected to complete the How to Build stage

  - you would see the text in console:

     Please enter 'exit' to quit
     Waiting for input...

  - To Create a new Parking Lot

     Command:
     ```sh
     create_parking_lot 6
     ```
     Output:
     ```sh
     Created parking lot with 6 slots
     ```

  - To Park a Car

       Command:

       ```sh
       park KA-01-HH-1234 White
       ```
       Output:

       ```sh
       Allocated slot number: 1
       ```

   - To Leave a parked car from lot

       Command:

       ```sh
       leave 1
       ```


       Output:

       ```sh
       Slot number 1 is free
       ```

   - To get Status report of ParkingLot

       Command:
       ```sh
       status
       ```
       Output:
       ```sh

                Slot No.        Registration No.        Color

                2                   KA-01-HH-9999       White
        ```

   - To get RegistrationNumbers of all Parked Cars with White color

        Command:

        ```sh
        registration_numbers_for_cars_with_colour White
        ```
        Output:

        ```sh
        KA-01-HH-9999
        ```

   - To get SlotNumbers of all Parked Cars with White color

        ```sh
        Command: slot_numbers_for_cars_with_colour White
        ```

        Output:
        ```sh
         2
        ```

   - To get SlotNumber of Parked Car with a specific Registration number

        Command:
        ```sh
        slot_number_for_registration_number KA-01-HH-3141
        ```

        Output:
        ```sh
         1
        ```

## How to use in file mode:

  - You are expected to complete the How to Build stage

  ```sh
     ./parking_lot.sh file_inputs.txt
  ```

   -  This will clean,build,install the package and run the commands in the file

   -  Filename specified is for explanation, you can set any name but it should be a valid text file
