package io.drawingtoolconsole.console.executor;

import io.drawingtoolconsole.commands.Command;
import io.drawingtoolconsole.commands.QuitCommand;

import java.util.Scanner;

public class QuitConsoleCommandArgumentHandler implements ConsoleCommandArgumentHandler
{
  @Override
  public Command toCommandFrom(Scanner scanner)
  {
    return new QuitCommand();
  }

}
