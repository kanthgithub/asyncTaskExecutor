package io.drawingtoolconsole.console.executor;

import io.drawingtoolconsole.commands.Command;
import io.drawingtoolconsole.commands.FillCommand;

import java.util.Scanner;

public class FillConsoleCommandArgumentHandler implements ConsoleCommandArgumentHandler
{
  @Override
  public Command toCommandFrom(Scanner scanner)
  {
    int x = scanner.nextInt();
    int y = scanner.nextInt();
    char color = scanner.next().charAt(0);

    return new FillCommand(x, y, color);
  }
}
