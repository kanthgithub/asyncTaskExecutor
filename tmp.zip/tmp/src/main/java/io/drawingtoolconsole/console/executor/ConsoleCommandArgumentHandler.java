package io.drawingtoolconsole.console.executor;

import io.drawingtoolconsole.commands.Command;

import java.util.Scanner;

public interface ConsoleCommandArgumentHandler
{
  Command toCommandFrom(Scanner scanner);
}
