package io.drawingtoolconsole.console.executor;

import io.drawingtoolconsole.commands.Command;

import java.util.Scanner;

public class AlienConsoleCommandArgumentHandler implements ConsoleCommandArgumentHandler
{
  @Override
  public Command toCommandFrom(Scanner scanner)
  {
    scanner.nextLine();
    throw new IllegalArgumentException("Cannot process Alien Commands");
  }
}
