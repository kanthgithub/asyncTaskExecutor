package io.drawingtoolconsole.console.executor;

import io.drawingtoolconsole.console.DrawingToolConsoleCommand;

import java.util.HashMap;
import java.util.Map;

public class ConsoleCommandArgumentHandlerFactory
{
  private final Map<DrawingToolConsoleCommand, ConsoleCommandArgumentHandler> handlerMap = new HashMap<DrawingToolConsoleCommand, ConsoleCommandArgumentHandler>();

  public ConsoleCommandArgumentHandlerFactory()
  {
    handlerMap.put(DrawingToolConsoleCommand.CREATE, new CreateConsoleCommandArgumentHandler());
    handlerMap.put(DrawingToolConsoleCommand.LINE, new LineConsoleCommandArgumentHandler());
    handlerMap.put(DrawingToolConsoleCommand.RECTANGLE, new RectangleConsoleCommandArgumentHandler());
    handlerMap.put(DrawingToolConsoleCommand.FILL, new FillConsoleCommandArgumentHandler());
    handlerMap.put(DrawingToolConsoleCommand.QUIT, new QuitConsoleCommandArgumentHandler());
    handlerMap.put(DrawingToolConsoleCommand.ALIEN, new AlienConsoleCommandArgumentHandler());
  }

  public ConsoleCommandArgumentHandler handlerFor(DrawingToolConsoleCommand drawingToolConsoleCommand)
  {
    return handlerMap.get(drawingToolConsoleCommand);
  }
}
