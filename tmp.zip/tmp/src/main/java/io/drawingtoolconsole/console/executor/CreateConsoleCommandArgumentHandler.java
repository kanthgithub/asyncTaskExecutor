package io.drawingtoolconsole.console.executor;

import io.drawingtoolconsole.commands.Command;
import io.drawingtoolconsole.commands.CreateCommand;

import java.util.Scanner;

public class CreateConsoleCommandArgumentHandler implements ConsoleCommandArgumentHandler
{
  @Override
  public Command toCommandFrom(Scanner scanner)
  {
    int width = scanner.nextInt();
    int height = scanner.nextInt();

    return new CreateCommand(width, height);
  }
}
