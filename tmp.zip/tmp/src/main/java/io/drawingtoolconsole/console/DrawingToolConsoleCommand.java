package io.drawingtoolconsole.console;

public enum DrawingToolConsoleCommand
{
  CREATE("C"),
  LINE("L"),
  RECTANGLE("R"),
  FILL("B"),
  QUIT("Q"),
  ALIEN("AL");

  private final String command;

  DrawingToolConsoleCommand(String _command)
  {
    this.command = _command;
  }

  private String getCommandCharacter()
  {
    return command;
  }

  public static DrawingToolConsoleCommand parse(String command)
  {
    for (DrawingToolConsoleCommand commandArg : values()) {
      if (commandArg.getCommandCharacter().equals(command)) {
        return commandArg;
      }
    }

    return ALIEN;
  }
}
