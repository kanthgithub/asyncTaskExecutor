package io.drawingtoolconsole.console;

import io.drawingtoolconsole.DrawingTool;
import io.drawingtoolconsole.commands.Command;
import io.drawingtoolconsole.console.executor.ConsoleCommandArgumentHandlerFactory;

import java.util.Scanner;

/**
 * Console interface to the <code>DrawingTool<code>
 */
public class ConsoleDrawingTool
{
  private final static ConsoleCommandArgumentHandlerFactory handlerFactory = new ConsoleCommandArgumentHandlerFactory();

  public static void main(String[] args)
  {
    Scanner scanner = new Scanner(System.in);
    DrawingTool drawingTool = new DrawingTool();
    DrawingToolConsoleCommand drawingToolConsoleCommand = DrawingToolConsoleCommand.ALIEN;

    do {
      System.out.print("enter command:");
      try {
        drawingToolConsoleCommand = DrawingToolConsoleCommand.parse(scanner.next());
        Command command = handlerFactory.handlerFor(drawingToolConsoleCommand).toCommandFrom(scanner);
        command.execute(drawingTool);

        StringBuilder sb = drawingTool.draw();

        System.out.println(sb);
      }
      catch (Exception ex) {
        System.out.println(ex.getMessage());
      }
    }
    while (drawingToolConsoleCommand != DrawingToolConsoleCommand.QUIT);

    scanner.close();
    System.exit(0);
  }
}
