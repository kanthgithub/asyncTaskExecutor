package io.drawingtoolconsole.commands;

import io.drawingtoolconsole.DrawingTool;

public class AlienCommand implements Command
{
  @Override
  public void execute(DrawingTool drawingTool)
  {
    throw new RuntimeException("Cannot execute AlienCommands");
  }
}
