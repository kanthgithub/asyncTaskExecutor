package io.drawingtoolconsole.commands;

import io.drawingtoolconsole.DrawingTool;
import lombok.*;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreateCommand implements Command
{
  private int width;
  private int height;

  @Override
  public void execute(DrawingTool drawingTool)
  {
    drawingTool.crateCanvas(width, height);
  }

}
