package io.drawingtoolconsole.commands;

import io.drawingtoolconsole.DrawingTool;

public interface Command
{
  void execute(DrawingTool drawingTool);
}
