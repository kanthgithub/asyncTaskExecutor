package io.drawingtoolconsole.commands;

import io.drawingtoolconsole.DrawingTool;
import lombok.*;


@Getter
@Setter
@ToString
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FillCommand implements Command
{
  private  int xCoordinate;
  private int yCoordinate;
  private char color;

  @Override
  public void execute(DrawingTool drawingTool)
  {
    drawingTool.fill(xCoordinate, yCoordinate, color);
  }

}
