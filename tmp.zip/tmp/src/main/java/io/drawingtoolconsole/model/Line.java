package io.drawingtoolconsole.model;

import lombok.*;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Line implements Shape
{
  private final static char REPRESENTATION = 'x';

  private int xCoordinate1;
  private int yCoordinate1;
  private int xCoordinate2;
  private int yCoordinate2;

  @Override
  public void addTo(Canvas canvas)
  {
    if (!validLineOnCanvas(canvas))
      throw new IllegalArgumentException("Invalid line!");

    if (isHorizontal()) {
      for (int i = 0; i <= length(); i++)
        canvas.lineAt(xCoordinate1 + i, yCoordinate1, REPRESENTATION);
    }
    else {
      for (int i = 0; i <= length(); i++)
        canvas.lineAt(xCoordinate1, yCoordinate1 + i, REPRESENTATION);
    }
  }

  private int length()
  {
    if (isHorizontal())
      return xCoordinate2 - xCoordinate1;
    return yCoordinate2 - yCoordinate1;
  }

  private boolean validLineOnCanvas(Canvas canvas)
  {
    // line completely on canvas?
    if (xCoordinate1 < 0 || yCoordinate1 < 0 || xCoordinate2 > canvas.width() || yCoordinate2 > canvas.height())
      return false;
    
    // diagonal line?
    if (xCoordinate1 != xCoordinate2 && yCoordinate1 != yCoordinate2)
      return false;

    return true;
  }

  private boolean isHorizontal()
  {
    return yCoordinate1 == yCoordinate2;
  }
}
