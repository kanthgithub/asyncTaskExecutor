package io.drawingtoolconsole.model;

import lombok.*;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Rectangle implements Shape
{
  private final static char REPRESENTATION = 'x';

  private int xCoordinate1;
  private int yCoordinate1;
  private int xCoordinate2;
  private int yCoordinate2;

  @Override
  public void addTo(Canvas canvas)
  {
    if (!validRectangleOnCanvas(canvas))
      throw new IllegalArgumentException("Invalid rectangle!");

    // horizontal lines
    for (int i = 0; i < width(); i++)
      canvas.lineAt(xCoordinate1 + i, yCoordinate1, REPRESENTATION);
    for (int i = 0; i < width(); i++)
      canvas.lineAt(xCoordinate1 + i, yCoordinate2, REPRESENTATION);

    // vertical lines
    for (int i = 0; i < height() - 2; i++)
      canvas.lineAt(xCoordinate1, yCoordinate1 + i + 1, REPRESENTATION);
    for (int i = 0; i < height() - 2; i++)
      canvas.lineAt(xCoordinate2, yCoordinate1 + i + 1, REPRESENTATION);
  }

  private int height()
  {
    return yCoordinate2 - yCoordinate1 + 1;
  }

  private int width()
  {
    return xCoordinate2 - xCoordinate1 + 1;
  }

  private boolean validRectangleOnCanvas(Canvas canvas)
  {
    if (xCoordinate1 < 0 || yCoordinate1 < 0 || xCoordinate2 > canvas.width() || yCoordinate2 > canvas.height())
      return false;

    return true;
  }
}
