package io.drawingtoolconsole.model;

public class Canvas
{
  private final static char BLANK = ' ';

  private final int         width;
  private final int         height;
  private final char[][]    squares;

  public Canvas(int w,
                int h)
  {
    width = w;
    height = h;
    squares = new char[w][h];

    for (int i = 0; i < width; i++) {
      for (int j = 0; j < height; j++)
        squares[i][j] = BLANK;
    }
  }

  public void lineAt(int xCoordinate,
                     int yCoordinate,
                     char c)
  {
    squares[xCoordinate - 1][yCoordinate - 1] = c;
  }

  public void fill(int xCoordinate,
                   int yCoordinate,
                   char c)
  {
    if (xCoordinate <= 0 || xCoordinate > width || yCoordinate <= 0 || yCoordinate > height || squares[xCoordinate - 1][yCoordinate - 1] != BLANK)
      return;

    squares[xCoordinate - 1][yCoordinate - 1] = c;

    fill(xCoordinate + 1, yCoordinate, c);
    fill(xCoordinate - 1, yCoordinate, c);
    fill(xCoordinate, yCoordinate + 1, c);
    fill(xCoordinate, yCoordinate - 1, c);
  }

  public StringBuilder draw()
  {

    StringBuilder sb = new StringBuilder();

    // top of canvas
    for (int i = 0; i < width + 2; i++) {
      sb.append('-');
    }

    sb.append("\n");

    for (int i = 0; i < height; i++) {
      sb.append('|');
      for (int j = 0; j < width; j++)
        sb.append(squares[j][i]);
      sb.append('|');
      sb.append("\n");
    }

    // bottom of canvas
    for (int i = 0; i < width + 2; i++) {
      sb.append('-');
    }

    return sb;
  }

  public int width()
  {
    return width;
  }

  public int height()
  {
    return height;
  }
}
