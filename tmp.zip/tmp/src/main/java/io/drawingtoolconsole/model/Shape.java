package io.drawingtoolconsole.model;


public interface Shape
{  
  void addTo(Canvas canvas);
}
